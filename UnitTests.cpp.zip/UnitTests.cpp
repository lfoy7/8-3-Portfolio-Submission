// Uncomment the next line to use precompiled headers
//include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
#include <gtest/gtest.h>

#include <cassert>
#include <cstdlib>
#include <ctime>
#include <memory>
#include <stdexcept>
#include <vector>

// Global test environment from the starter code.
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  void SetUp() override
  {
    srand(time(nullptr));
  }

  void TearDown() override {}
};

// Shared setup for the collection tests.
class CollectionTest : public ::testing::Test
{
protected:
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  {
    collection.reset(new std::vector<int>);
  }

  void TearDown() override
  {
    collection->clear();
    collection.reset(nullptr);
  }

  void add_entries(int count)
  {
    assert(count > 0);
    for (int i = 0; i < count; ++i)
    {
      collection->push_back(rand() % 100);
    }
  }
};

TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  ASSERT_TRUE(collection);
  ASSERT_NE(collection.get(), nullptr);
}

TEST_F(CollectionTest, IsEmptyOnCreate)
{
  ASSERT_TRUE(collection->empty());
  ASSERT_EQ(collection->size(), 0);
}

// AlwaysFail from the starter code is intentionally left out because it
// calls FAIL() and would make the completed test suite fail.

TEST_F(CollectionTest, CanAddToEmptyVector)
{
  ASSERT_TRUE(collection->empty());
  ASSERT_EQ(collection->size(), 0);

  add_entries(1);

  EXPECT_FALSE(collection->empty());
  EXPECT_EQ(collection->size(), 1);
}

TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  add_entries(5);

  EXPECT_FALSE(collection->empty());
  EXPECT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, MaxSizeIsAtLeastSize)
{
  ASSERT_EQ(collection->size(), 0);
  EXPECT_GE(collection->max_size(), collection->size()); // 0 entries

  add_entries(1);
  ASSERT_EQ(collection->size(), 1);
  EXPECT_GE(collection->max_size(), collection->size()); // 1 entry

  add_entries(4);
  ASSERT_EQ(collection->size(), 5);
  EXPECT_GE(collection->max_size(), collection->size()); // 5 entries

  add_entries(5);
  ASSERT_EQ(collection->size(), 10);
  EXPECT_GE(collection->max_size(), collection->size()); // 10 entries
}

TEST_F(CollectionTest, CapacityIsAtLeastSize)
{
  ASSERT_EQ(collection->size(), 0);
  EXPECT_GE(collection->capacity(), collection->size()); // 0 entries

  add_entries(1);
  ASSERT_EQ(collection->size(), 1);
  EXPECT_GE(collection->capacity(), collection->size()); // 1 entry

  add_entries(4);
  ASSERT_EQ(collection->size(), 5);
  EXPECT_GE(collection->capacity(), collection->size()); // 5 entries

  add_entries(5);
  ASSERT_EQ(collection->size(), 10);
  EXPECT_GE(collection->capacity(), collection->size()); // 10 entries
}

TEST_F(CollectionTest, ResizeIncreasesSize)
{
  collection->resize(5);

  ASSERT_EQ(collection->size(), 5);
  EXPECT_EQ(collection->at(4), 0);
}

TEST_F(CollectionTest, ResizeDecreasesSize)
{
  add_entries(5);
  collection->resize(2);

  EXPECT_EQ(collection->size(), 2);
}

TEST_F(CollectionTest, ResizeToZero)
{
  add_entries(5);
  collection->resize(0);

  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, ClearErasesCollection)
{
  add_entries(5);
  collection->clear();

  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, EraseRangeErasesCollection)
{
  add_entries(5);
  collection->erase(collection->begin(), collection->end());

  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, ReserveIncreasesCapacityButNotSize)
{
  const auto originalSize = collection->size();
  const auto requestedCapacity = collection->capacity() + 10;

  collection->reserve(requestedCapacity);

  EXPECT_GE(collection->capacity(), requestedCapacity);
  EXPECT_EQ(collection->size(), originalSize);
}

TEST_F(CollectionTest, AtThrowsForOutOfBoundsIndex)
{
  EXPECT_THROW(collection->at(0), std::out_of_range);
}

// Original positive test: verify that an added value can be read back.
TEST_F(CollectionTest, CanReadAddedValue)
{
  collection->push_back(42);

  ASSERT_EQ(collection->size(), 1);
  EXPECT_EQ(collection->at(0), 42);
}

// Original negative test: verify that reading past the end throws.
TEST_F(CollectionTest, CannotReadPastLastValue)
{
  collection->push_back(42);

  ASSERT_EQ(collection->size(), 1);
  EXPECT_THROW(collection->at(1), std::out_of_range);
}