// Exceptions.cpp
#include <exception>
#include <iostream>
#include <stdexcept>

class CustomApplicationException : public std::exception
{
public:
  const char* what() const noexcept override
  {
    return "Custom application logic encountered an error.";
  }
};

bool do_even_more_custom_application_logic()
{
  throw std::runtime_error("Even more custom logic failed.");

  // This line is unreachable while the exception above is thrown.
  std::cout << "Running Even More Custom Application Logic." << std::endl;
  return true;
}

void do_custom_application_logic()
{
  std::cout << "Running Custom Application Logic." << std::endl;

  try
  {
    if (do_even_more_custom_application_logic())
    {
      std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }
  }
  catch (const std::exception& ex)
  {
    std::cout << "Caught standard exception: " << ex.what() << std::endl;
  }

  std::cout << "Leaving Custom Application Logic." << std::endl;
  throw CustomApplicationException{};
}

float divide(float num, float den)
{
  if (den == 0.0f)
  {
    throw std::invalid_argument("Cannot divide by zero.");
  }

  return num / den;
}

void do_division() noexcept
{
  float numerator = 10.0f;
  float denominator = 0.0f;

  try
  {
    auto result = divide(numerator, denominator);
    std::cout << "divide(" << numerator << ", " << denominator
              << ") = " << result << std::endl;
  }
  catch (const std::invalid_argument& ex)
  {
    std::cout << "Division error: " << ex.what() << std::endl;
  }
}

int main()
{
  try
  {
    std::cout << "Exceptions Tests!" << std::endl;

    do_division();
    do_custom_application_logic();
  }
  catch (const CustomApplicationException& ex)
  {
    std::cout << "Caught custom exception: " << ex.what() << std::endl;
  }
  catch (const std::exception& ex)
  {
    std::cout << "Caught standard exception in main: " << ex.what() << std::endl;
  }
  catch (...)
  {
    std::cout << "Caught an unknown exception in main." << std::endl;
  }
}