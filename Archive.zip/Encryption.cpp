// Encryption.cpp - Character-by-character XOR demonstration.
#include <cassert>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>

std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    const auto key_length = key.length();
    const auto source_length = source.length();
    // Runtime checks still protect inputs when assertions are disabled.
    if (key_length == 0 || source_length == 0)
        throw std::invalid_argument("Source and key must not be empty.");
    assert(key_length > 0);
    assert(source_length > 0);
    std::string output = source;
    for (std::size_t i = 0; i < source_length; ++i)
    {
        // Modulo repeats the key without indexing beyond its length.
        output[i] = static_cast<char>(source[i] ^ key[i % key_length]);
    }
    assert(output.length() == source_length);
    return output;
}

std::string read_file(const std::string& filename)
{
    // Preserve all bytes, including newlines and embedded null characters.
    std::ifstream input(filename, std::ios::binary);
    if (!input)
        throw std::runtime_error("Cannot open input file: " + filename);
    std::ostringstream contents;
    contents << input.rdbuf();
    if (input.bad() || !contents)
        throw std::runtime_error("Cannot read input file: " + filename);
    return contents.str();
}

std::string get_student_name(const std::string& string_data)
{
    const std::size_t pos = string_data.find('\n');
    if (pos == std::string::npos)
        throw std::runtime_error("Input must contain a name on its first line.");
    std::string student_name = string_data.substr(0, pos);
    // Windows line endings include a carriage return before the newline.
    if (!student_name.empty() && student_name.back() == '\r')
        student_name.pop_back();
    if (student_name.empty())
        throw std::runtime_error("Student name must not be empty.");
    return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name,
                    const std::string& key, const std::string& data)
{
    const std::time_t current_time = std::time(nullptr);
    const std::tm* local_time = std::localtime(&current_time);
    if (current_time == static_cast<std::time_t>(-1) || local_time == nullptr)
        throw std::runtime_error("Cannot obtain the current date.");
    // RAII closes the stream automatically; binary mode preserves XOR bytes.
    std::ofstream output(filename, std::ios::binary | std::ios::trunc);
    if (!output)
        throw std::runtime_error("Cannot open output file: " + filename);
    output << student_name << '\n'
           << std::put_time(local_time, "%Y-%m-%d") << '\n'
           << key << '\n';
    // Write the complete string, even if encryption produces null bytes.
    output.write(data.data(), static_cast<std::streamsize>(data.size()));
    output.close();
    if (!output)
        throw std::runtime_error("Cannot save output file: " + filename);
}

int main()
{
    try
    {
        std::cout << "Encryption Decryption Test!\n";
        const std::string file_name = "inputdatafile.txt";
        const std::string encrypted_file_name = "encrypteddatafile.txt";
        // Preserve the assignment's exact filename, including its spelling.
        const std::string decrypted_file_name = "decrytpteddatafile.txt";
        const std::string source_string = read_file(file_name);
        const std::string key = "password";
        const std::string student_name = get_student_name(source_string);
        const std::string encrypted_string = encrypt_decrypt(source_string, key);
        save_data_file(encrypted_file_name, student_name, key, encrypted_string);
        const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);
        if (decrypted_string != source_string)
            throw std::runtime_error("Decryption did not restore the original data.");
        save_data_file(decrypted_file_name, student_name, key, decrypted_string);
        std::cout << "Read File: " << file_name
                  << " - Encrypted To: " << encrypted_file_name
                  << " - Decrypted To: " << decrypted_file_name << '\n'
                  << "Verification passed: decrypted data matches original.\n";
    }
    catch (const std::exception& error)
    {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
