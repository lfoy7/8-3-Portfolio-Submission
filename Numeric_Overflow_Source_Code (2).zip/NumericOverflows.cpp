// NumericOverflows.cpp : Demonstrates safe numeric addition and subtraction.

#include <iostream>
#include <limits>
#include <string>
#include <typeinfo>

/// Adds increment once per step. Returns false before an operation would exceed
/// the greatest value represented by T, leaving result at the last safe value.
template <typename T>
bool add_numbers(T const& start, T const& increment,
                 unsigned long int const& steps, T& result)
{
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Rearranging result + increment <= max avoids performing an unsafe add.
        if (increment > 0 && result > std::numeric_limits<T>::max() - increment)
        {
            return false;
        }

        // This also makes the template safe if a signed negative increment is used.
        if (increment < 0 && result < std::numeric_limits<T>::lowest() - increment)
        {
            return false;
        }

        result += increment;
    }

    return true;
}

/// Subtracts decrement once per step. For this activity, underflow means that
/// the nonnegative running total would fall below zero. Returns false before
/// the unsafe subtraction and leaves result at the last safe value.
template <typename T>
bool subtract_numbers(T const& start, T const& decrement,
                      unsigned long int const& steps, T& result)
{
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Comparing first prevents unsigned wraparound and crossing the zero floor.
        if (decrement > result)
        {
            return false;
        }

        result -= decrement;
    }

    return true;
}

// Unary + forces character types to print as numbers rather than characters.
template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    const unsigned long int steps = 5;
    const T increment = std::numeric_limits<T>::max() / steps;
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    T result{};
    bool success = add_numbers<T>(start, increment, steps, result);
    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", "
              << +increment << ", " << steps << ") = Overflow: "
              << std::boolalpha << !success << ", Result: " << +result << std::endl;

    success = add_numbers<T>(start, increment, steps + 1, result);
    std::cout << "\tAdding Numbers With Overflow (" << +start << ", "
              << +increment << ", " << (steps + 1) << ") = Overflow: "
              << std::boolalpha << !success << ", Result: " << +result << std::endl;
}

template <typename T>
void test_underflow()
{
    // START DO NOT CHANGE
    const unsigned long int steps = 5;
    const T decrement = std::numeric_limits<T>::max() / steps;
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    T result{};
    bool success = subtract_numbers<T>(start, decrement, steps, result);
    std::cout << "\tSubtracting Numbers Without Underflow (" << +start << ", "
              << +decrement << ", " << steps << ") = Underflow: "
              << std::boolalpha << !success << ", Result: " << +result << std::endl;

    success = subtract_numbers<T>(start, decrement, steps + 1, result);
    std::cout << "\tSubtracting Numbers With Underflow (" << +start << ", "
              << +decrement << ", " << (steps + 1) << ") = Underflow: "
              << std::boolalpha << !success << ", Result: " << +result << std::endl;
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Underflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

int main()
{
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;
    do_overflow_tests(star_line);
    do_underflow_tests(star_line);
    std::cout << std::endl
              << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}
